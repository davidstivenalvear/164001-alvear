#!/usr/bin/env python3
 
# Autor: david stiven alvear delgado
# Curso: Estructuras de Datos - Universidad Libre - Seccional Cali
# Programa: parcial2.py
# Fecha: thu mayo 11 7:45:49 COT 2017
# Descripcion: este programa calcula el promedio de los estudiantes por edad, por ciudad, promedio mas alto y bajo y el promedio de notas por ciudad 
 
# Librerias
import pickle
 
# Constantes
 
# Clases
 
class Alumno:
    def __init__(self, codigo, nombre, apellido, edad, ciudad, telefono, notas):
        self.notas = notas
        self.nombre = nombre
        self.apellido = apellido
        self.edad = edad
        self.ciudad = ciudad
        self.telefono = telefono
    def __str__(self):
        return self.notas
        pass
    def promedio(self):
        return sum(self.notas) / len(self.notas)
    def nombrealum(self):
        return (self.nombre) 
    def averageedad(self):
        return (self.edad)
    def citybyage(self):
        return (self.ciudad)

 
# Variables
 
# Metodos
def cargar(alumnos_pickle):
    """ (string) -> lista
   
   Carga los datos desde el archivo, y retorna una lista de objetos Alumno
   
   """
    lista = list()
    archivo = open('alumnos.pickle', 'rb')
    datos = pickle.load(archivo)    
    # ciclo para recorrer datos
    for ciclo in datos.items():
        # crear cada objeto
      #                    codigo,      nombre,    apellido,        edad,      ciudad,    telefono,   notas 
      estudiante = Alumno(ciclo[0], ciclo[1][0], ciclo[1][1], ciclo[1][2], ciclo[1][3], ciclo[1][4], ciclo[1][5])
       
        # agregarlo a la lista
      lista.append(estudiante)  
    # devuelve la lista
    return lista
def promedioTotal(alumnos):
    """ list(Alumno) -> number
 
   Calcula el promedio total de las notas de los alumnos en la lista
 
   >>> alumnos = list()
   >>> alumnos.append(Alumno(51706891, "maria", "galarza", 19, "medellin", 3317692, [3.8, 2.6, 1.0, 2.5, 3.2]))
   >>> alumnos.append(Alumno(41380016, "beatriz", "jacome", 21, "cali", 8871130, [3.7, 3.6, 1.5, 4.1, 1.7]))
   >>> promedioTotal(alumnos)
   2.77
   >>> alumnos = list()
   >>> alumnos.append(Alumno(4148316, "jaime", "diaz", 20, "cali", 4459988, [2.2, 4.2, 4.9, 4.5, 3.1]))
   >>> alumnos.append(Alumno(98523512, "rodrigo", "romero", 21, "cali", 4481870, [4.6, 4.9, 3.9, 4.1, 5.0]))
   >>> promedioTotal(alumnos)
   4.140000000000001
   
   """
    suma = 0.0
    cantidad = 0
    promedio = 0
    # recorrer toda la lista
    for alumno in alumnos:
        # calcular la suma de las notas, y la cantidad
        suma += alumno.promedio()
        cantidad += 1
    # devuelve el promedio
    return suma/cantidad
def promediomasalto(alumnos):
    promedio = 0.0
    estudiante = ''
    nombre = ''
    apellido = ''
    for alumno in alumnos:

      if alumno.promedio() > promedio:
        promedio = alumno.promedio()
        nombre= alumno.nombre
        apellido = alumno.apellido
    return (promedio,nombre,apellido)    
def promediobajo(alumnos):
    
    promedio = 8.0
    estudiante = ''
    nombre = ''
    apellido = ''
    for alumno in alumnos:

      if alumno.promedio() < promedio:
        promedio = alumno.promedio()
        nombre= alumno.nombre
        apellido = alumno.apellido
    return (promedio,nombre,apellido)     
def average(alumnos):

    suma = 0
    cantidad = 0
    # recorrer toda la lista
    for alumno in alumnos:
        # calcular la suma de las notas, y la cantidad
        suma += alumno.averageedad()
        cantidad += 1
    # devuelve el promedio
    return int(suma / cantidad) 
def agebycity(alumnos):

    prom_alumno = dict()
    ciudades = dict()
    for alumno in alumnos:
        if alumno.ciudad in ciudades:
          ciudades[alumno.ciudad] = [ciudades[alumno.ciudad][0] + alumno.edad, ciudades[alumno.ciudad][1] + 1]
        else: 
          ciudades[alumno.ciudad] = [alumno.edad,1]
        prom_alumno[alumno.ciudad] =  ciudades[alumno.ciudad][0] / ciudades[alumno.ciudad][1]
    return prom_alumno
def gradebyage(alumnos):

    prom_edad = dict()
    edades = dict()
    for alumno in alumnos:
        if alumno.edad in edades:
          edades[alumno.edad] = [edades[alumno.edad][0] + alumno.promedio(), edades[alumno.edad][1] + 1]
        else:
          edades[alumno.edad] = [alumno.promedio(),1]
        prom_edad[alumno.edad] =  edades[alumno.edad][0] / edades[alumno.edad][1]
    return prom_edad
# Pruebas
def gradebycity(alumnos):

    prom_alumno = dict()
    ciudades = dict()
    for alumno in alumnos:
        if alumno.ciudad in ciudades:
          ciudades[alumno.ciudad] = [ciudades[alumno.ciudad][0] + alumno.promedio(), ciudades[alumno.ciudad][1] + 1]
        else: 
          ciudades[alumno.ciudad] = [alumno.promedio(),1]
        prom_alumno[alumno.ciudad] =  ciudades[alumno.ciudad][0] / ciudades[alumno.ciudad][1]
    return prom_alumno
if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Programa Principal

estudiantes = cargar('alumnos.pickle')
prom_total = promedioTotal(estudiantes)
print('promedio total de notas  :', prom_total)
prom_mayor = promediomasalto(estudiantes)
print('promedio mas alto es:',prom_mayor)
prom_menor= promediobajo(estudiantes)
print('promedio mas bajo es:',prom_menor)
prom_edad = average(estudiantes)
print('promedio total edad: ',prom_edad)
prom_edadcity= agebycity(estudiantes)
print('promedio edad por ciudad',prom_edadcity)
prom_gradeage = gradebyage(estudiantes)
print('promedio notas por edad',prom_gradeage)
prom_gradecity = gradebycity(estudiantes)
print('promedio notas por ciudad:',prom_gradecity)
